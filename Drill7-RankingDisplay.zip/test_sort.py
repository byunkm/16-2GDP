data = [32,31,32,38,98,100,77,22,12,16,9]

def bubble_sort(data):
    for i in range(0,len(data)):
        for j in range(i+1,len(data)):
            if data[i] < data[j]:
                data[i], data[j] = data[j], data[i]

bubble_sort(data)
print(data)

