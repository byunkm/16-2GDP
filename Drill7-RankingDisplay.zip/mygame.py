import game_framework
import title_state
import pico2d
import json

pico2d.open_canvas()
game_framework.run(title_state)
pico2d.close_canvas()